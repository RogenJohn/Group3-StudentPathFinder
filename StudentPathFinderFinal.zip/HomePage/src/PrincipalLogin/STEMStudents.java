package PrincipalLogin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JTextPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

import SecretaryLogin.SecretaryLogin;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class STEMStudents {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					STEMStudents window = new STEMStudents();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public STEMStudents() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSTEMStudents = new JLabel("LIST OF STEM STUDENTS");
		lblSTEMStudents.setFont(new Font("Tahoma", Font.BOLD, 34));
		lblSTEMStudents.setBounds(74, 79, 432, 35);
		frame.getContentPane().add(lblSTEMStudents);
		
		JTextPane STEMStudent1 = new JTextPane();
		STEMStudent1.setDisabledTextColor(Color.BLACK);
		STEMStudent1.setEnabled(false);
		STEMStudent1.setFont(new Font("Tahoma", Font.BOLD, 14));
		STEMStudent1.setBackground(Color.LIGHT_GRAY);
		STEMStudent1.setText("ABATAYO, CRISTAL ANN");
		STEMStudent1.setBounds(50, 149, 235, 23);
		frame.getContentPane().add(STEMStudent1);
		
		JTextPane STEMStudent2 = new JTextPane();
		STEMStudent2.setDisabledTextColor(Color.BLACK);
		STEMStudent2.setEnabled(false);
		STEMStudent2.setFont(new Font("Tahoma", Font.BOLD, 14));
		STEMStudent2.setText("BORJA, KATE MARIE");
		STEMStudent2.setBackground(Color.LIGHT_GRAY);
		STEMStudent2.setBounds(50, 206, 235, 23);
		frame.getContentPane().add(STEMStudent2);
		
		JButton btnSTEMStudent2INFO = new JButton("INFO");
		btnSTEMStudent2INFO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentRecord2 info = new StudentRecord2();
				StudentRecord2.main(null);
			}
		});
		btnSTEMStudent2INFO.setForeground(Color.RED);
		btnSTEMStudent2INFO.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent2INFO.setBounds(290, 206, 89, 23);
		frame.getContentPane().add(btnSTEMStudent2INFO);
		
		JButton btnSTEMStudent2GRADES = new JButton("GRADES");
		btnSTEMStudent2GRADES.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				STEMStudentGrades1Student2 info = new STEMStudentGrades1Student2();
				STEMStudentGrades1Student2.main(null);
			}
		});
		btnSTEMStudent2GRADES.setForeground(Color.RED);
		btnSTEMStudent2GRADES.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent2GRADES.setBounds(389, 206, 117, 23);
		frame.getContentPane().add(btnSTEMStudent2GRADES);
		
		JTextPane STEMStudent3 = new JTextPane();
		STEMStudent3.setDisabledTextColor(Color.BLACK);
		STEMStudent3.setEnabled(false);
		STEMStudent3.setText("CUENCO, JOSH");
		STEMStudent3.setFont(new Font("Tahoma", Font.BOLD, 14));
		STEMStudent3.setBackground(Color.LIGHT_GRAY);
		STEMStudent3.setBounds(50, 263, 235, 23);
		frame.getContentPane().add(STEMStudent3);
		
		JButton btnSTEMStudent3INFO = new JButton("INFO");
		btnSTEMStudent3INFO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentRecord3 info = new StudentRecord3();
				StudentRecord3.main(null);
			}
		});
		btnSTEMStudent3INFO.setForeground(Color.RED);
		btnSTEMStudent3INFO.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent3INFO.setBounds(290, 263, 89, 23);
		frame.getContentPane().add(btnSTEMStudent3INFO);
		
		JButton btnSTEMStudent3GRADES = new JButton("GRADES");
		btnSTEMStudent3GRADES.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				STEMStudentGrades1Student3 info = new STEMStudentGrades1Student3();
				STEMStudentGrades1Student3.main(null);
			}
		});
		btnSTEMStudent3GRADES.setForeground(Color.RED);
		btnSTEMStudent3GRADES.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent3GRADES.setBounds(389, 263, 117, 23);
		frame.getContentPane().add(btnSTEMStudent3GRADES);
		
		JTextPane STEMStudent4 = new JTextPane();
		STEMStudent4.setDisabledTextColor(Color.BLACK);
		STEMStudent4.setEnabled(false);
		STEMStudent4.setText("DOMINGO, HAZEL");
		STEMStudent4.setFont(new Font("Tahoma", Font.BOLD, 14));
		STEMStudent4.setBackground(Color.LIGHT_GRAY);
		STEMStudent4.setBounds(50, 318, 235, 23);
		frame.getContentPane().add(STEMStudent4);
		
		JButton btnSTEMStudent4INFO = new JButton("INFO");
		btnSTEMStudent4INFO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentRecord4 info = new StudentRecord4();
				StudentRecord4.main(null);
			}
		});
		btnSTEMStudent4INFO.setForeground(Color.RED);
		btnSTEMStudent4INFO.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent4INFO.setBounds(290, 318, 89, 23);
		frame.getContentPane().add(btnSTEMStudent4INFO);
		
		JButton btnSTEMStudent4GRADES = new JButton("GRADES");
		btnSTEMStudent4GRADES.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				STEMStudentGrades1Student4 info = new STEMStudentGrades1Student4();
				STEMStudentGrades1Student4.main(null);
			}
		});
		btnSTEMStudent4GRADES.setForeground(Color.RED);
		btnSTEMStudent4GRADES.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent4GRADES.setBounds(389, 318, 117, 23);
		frame.getContentPane().add(btnSTEMStudent4GRADES);
		
		JTextPane STEMStudent5 = new JTextPane();
		STEMStudent5.setDisabledTextColor(Color.BLACK);
		STEMStudent5.setEnabled(false);
		STEMStudent5.setText("GACHO, SYCLONE JADE");
		STEMStudent5.setFont(new Font("Tahoma", Font.BOLD, 14));
		STEMStudent5.setBackground(Color.LIGHT_GRAY);
		STEMStudent5.setBounds(50, 375, 235, 23);
		frame.getContentPane().add(STEMStudent5);
		
		JButton btnSTEMStudent5INFO = new JButton("INFO");
		btnSTEMStudent5INFO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentRecord5 info = new StudentRecord5();
				StudentRecord5.main(null);
			}
		});
		btnSTEMStudent5INFO.setForeground(Color.RED);
		btnSTEMStudent5INFO.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent5INFO.setBounds(290, 375, 89, 23);
		frame.getContentPane().add(btnSTEMStudent5INFO);
		
		JButton btnSTEMStudent5GRADES = new JButton("GRADES");
		btnSTEMStudent5GRADES.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				STEMStudentGrades1Student5 info = new STEMStudentGrades1Student5();
				STEMStudentGrades1Student5.main(null);
			}
		});
		btnSTEMStudent5GRADES.setForeground(Color.RED);
		btnSTEMStudent5GRADES.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent5GRADES.setBounds(389, 375, 117, 23);
		frame.getContentPane().add(btnSTEMStudent5GRADES);
		
		JButton btnSTEMStudent1INFO = new JButton("INFO");
		btnSTEMStudent1INFO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentRecord info = new StudentRecord();
				StudentRecord.main(null);
			}
		});
		btnSTEMStudent1INFO.setForeground(Color.RED);
		btnSTEMStudent1INFO.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent1INFO.setBounds(290, 149, 89, 23);
		frame.getContentPane().add(btnSTEMStudent1INFO);
		
		JButton btnSTEMStudent1GRADES = new JButton("GRADES");
		btnSTEMStudent1GRADES.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				STEMStudentGrades1Student1 info = new STEMStudentGrades1Student1();
				STEMStudentGrades1Student1.main(null);
			}
		});
		btnSTEMStudent1GRADES.setForeground(Color.RED);
		btnSTEMStudent1GRADES.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent1GRADES.setBounds(389, 149, 117, 23);
		frame.getContentPane().add(btnSTEMStudent1GRADES);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentPathFinder info = new StudentPathFinder();
				StudentPathFinder.main(null);
			}});
		btnBack.setBounds(50, 459, 89, 23);
		frame.getContentPane().add(btnBack);
		frame.setBounds(100, 100, 590, 567);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
