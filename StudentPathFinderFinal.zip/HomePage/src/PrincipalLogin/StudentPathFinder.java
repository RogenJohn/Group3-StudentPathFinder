package PrincipalLogin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JTextPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

import HomePage.HomePage;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class StudentPathFinder {

	private JFrame frame;
	private JTextField txtField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentPathFinder window = new StudentPathFinder();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudentPathFinder() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setEnabled(false);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSTEMStudents = new JLabel("SEARCH FOR STRAND");
		lblSTEMStudents.setFont(new Font("Tahoma", Font.BOLD, 34));
		lblSTEMStudents.setBounds(83, 80, 432, 35);
		frame.getContentPane().add(lblSTEMStudents);
		
		JButton btnSEARCH = new JButton("SEARCH");
		btnSEARCH.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					String stem = txtField.getText();
					String ict = txtField.getText();
					
					if (stem.contains("STEM")){
						txtField.setText(null);
						
						STEMStudents info = new STEMStudents ();
						STEMStudents.main(null);
						
					}
					else if (ict.contains("ICT")){
						ICTStudents info = new ICTStudents ();
						ICTStudents.main(null);
					}
					else
					{
						JOptionPane.showMessageDialog(null, "You entered an invalid keyword.", "Invalid Strand", JOptionPane.ERROR_MESSAGE);
					
					}}	
		});
		btnSEARCH.setBounds(321, 248, 89, 26);
		frame.getContentPane().add(btnSEARCH);
		
		txtField = new JTextField();
		txtField.setBounds(122, 248, 149, 26);
		frame.getContentPane().add(txtField);
		txtField.setColumns(10);
		
		JButton btnLOGOUT = new JButton("LOGOUT");
		btnLOGOUT.setBackground(Color.LIGHT_GRAY);
		btnLOGOUT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame frmlogin = new JFrame("Exit");
				if (JOptionPane.showConfirmDialog(frmlogin, "Do you want to logout?", "Logging out", JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION)
				System.exit(0);
			}
		});
		btnLOGOUT.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnLOGOUT.setBounds(321, 407, 89, 23);
		frame.getContentPane().add(btnLOGOUT);
		
		JButton btnSWITCH = new JButton("SWITCH ACCOUNT");
		btnSWITCH.setBackground(Color.LIGHT_GRAY);
		btnSWITCH.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame frmlogin = new JFrame("Switch Account");
				if (JOptionPane.showConfirmDialog(frmlogin, "Do you want to switch account?", "Switching Account", JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION);
				HomePage info = new HomePage();
				HomePage.main(null);
			}
		});
		btnSWITCH.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSWITCH.setBounds(122, 407, 149, 23);
		frame.getContentPane().add(btnSWITCH);
		frame.setBounds(100, 100, 590, 567);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
