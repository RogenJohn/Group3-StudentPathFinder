package PrincipalLogin;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import HomePage.HomePage;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import PrincipalLogin.StudentPathFinder;

public class PrincipalLogin {

	private JFrame frame;
	private JPasswordField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PrincipalLogin window = new PrincipalLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PrincipalLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setForeground(Color.WHITE);
		frame.setBounds(100, 100, 590, 567);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setIcon(new ImageIcon(PrincipalLogin.class.getResource("/res/SWULOGO.png")));
		lblNewLabel.setBounds(81, 11, 400, 119);
		frame.getContentPane().add(lblNewLabel);
		
		
		JLabel lblPasswordTxt = new JLabel("Password:");
		lblPasswordTxt.setForeground(Color.RED);
		lblPasswordTxt.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblPasswordTxt.setBounds(162, 237, 98, 29);
		frame.getContentPane().add(lblPasswordTxt);
		
		JButton btnLOGIN = new JButton("LOGIN");
		btnLOGIN.setBackground(Color.LIGHT_GRAY);
		btnLOGIN.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnLOGIN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String password = txtPassword.getText();
				
				if (password.contains("principal123")) {
					txtPassword.setText(null);
					
					StudentPathFinder info = new StudentPathFinder();
					StudentPathFinder.main(null);
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Incorrect Password", "Login Error", JOptionPane.ERROR_MESSAGE);
					txtPassword.setText(null);
					
				}
			}
		});
		btnLOGIN.setForeground(Color.RED);
		btnLOGIN.setBounds(375, 400, 106, 36);
		frame.getContentPane().add(btnLOGIN);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(249, 244, 122, 20);
		frame.getContentPane().add(txtPassword);
		
		JButton btnBACK = new JButton("BACK");
		btnBACK.setBackground(Color.LIGHT_GRAY);
		btnBACK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomePage info = new HomePage();
				HomePage.main(null);
			}
		});
		btnBACK.setForeground(Color.RED);
		btnBACK.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnBACK.setBounds(81, 400, 98, 36);
		frame.getContentPane().add(btnBACK);
	}
}
