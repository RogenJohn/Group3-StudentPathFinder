package PrincipalLogin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JFormattedTextField;
import javax.swing.SwingConstants;

import PrincipalLogin.StudentPathFinder;

import java.awt.ComponentOrientation;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StudentRecord5 {

	private JFrame frame;
	private JTextField txtElemSY;
	private JTextField txtJHSSY;
	private JTextField ElementaryTxtField;
	private JTextField txtElem;
	private JTextField txtJHSName;
	private JTextField txtName;
	private JTextField txtAge;
	private JTextField txtSex;
	private JTextField txtAddress;
	private JTextField txtDoB;
	private JTextField txtParent;
	private JTextField txtLRN;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentRecord5 window = new StudentRecord5();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudentRecord5() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 590, 567);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblName.setBounds(10, 21, 40, 20);
		frame.getContentPane().add(lblName);
		
		JLabel lblLRN = new JLabel("LRN:");
		lblLRN.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblLRN.setBounds(350, 21, 40, 20);
		frame.getContentPane().add(lblLRN);
		
		JLabel lblDOB = new JLabel("Date of Birth:");
		lblDOB.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblDOB.setBounds(10, 224, 75, 20);
		frame.getContentPane().add(lblDOB);
		
		JLabel lblParent = new JLabel("Parent/Guardian:");
		lblParent.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblParent.setBounds(10, 255, 101, 20);
		frame.getContentPane().add(lblParent);
		
		JLabel lblSchool = new JLabel("School Attended");
		lblSchool.setHorizontalAlignment(SwingConstants.CENTER);
		lblSchool.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 18));
		lblSchool.setBounds(10, 287, 534, 20);
		frame.getContentPane().add(lblSchool);
		
		JLabel lblElementaryName = new JLabel("Elementary:");
		lblElementaryName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblElementaryName.setBounds(10, 336, 124, 20);
		frame.getContentPane().add(lblElementaryName);
		
		JLabel lblJHS = new JLabel("Junior High School:");
		lblJHS.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblJHS.setBounds(10, 367, 124, 20);
		frame.getContentPane().add(lblJHS);
		
		JLabel lblElementaryGraduate = new JLabel("Year Graduated:");
		lblElementaryGraduate.setBounds(379, 336, 101, 20);
		frame.getContentPane().add(lblElementaryGraduate);
		
		JLabel lblJHSGraduate = new JLabel("Year Graduated:");
		lblJHSGraduate.setBounds(379, 367, 101, 20);
		frame.getContentPane().add(lblJHSGraduate);
		
		txtElemSY = new JTextField();
		txtElemSY.setEnabled(false);
		txtElemSY.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtElemSY.setDisabledTextColor(Color.RED);
		txtElemSY.setSelectionColor(Color.RED);
		txtElemSY.setText("2015");
		txtElemSY.setHorizontalAlignment(SwingConstants.CENTER);
		txtElemSY.setBounds(478, 336, 86, 20);
		frame.getContentPane().add(txtElemSY);
		txtElemSY.setColumns(10);
		
		txtJHSSY = new JTextField();
		txtJHSSY.setEnabled(false);
		txtJHSSY.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtJHSSY.setDisabledTextColor(Color.RED);
		txtJHSSY.setSelectionColor(Color.RED);
		txtJHSSY.setHorizontalAlignment(SwingConstants.CENTER);
		txtJHSSY.setText("2019");
		txtJHSSY.setColumns(10);
		txtJHSSY.setBounds(478, 367, 86, 20);
		frame.getContentPane().add(txtJHSSY);
		
		JLabel lblAddress = new JLabel("Address:");
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAddress.setBounds(10, 120, 124, 20);
		frame.getContentPane().add(lblAddress);
		
		JLabel lblAge = new JLabel("Age:");
		lblAge.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAge.setBounds(10, 52, 40, 20);
		frame.getContentPane().add(lblAge);
		
		JLabel lblSex = new JLabel("Sex:");
		lblSex.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblSex.setBounds(10, 84, 40, 20);
		frame.getContentPane().add(lblSex);
		
		txtElem = new JTextField();
		txtElem.setEnabled(false);
		txtElem.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtElem.setDisabledTextColor(Color.RED);
		txtElem.setText("SOUTHWESTERN UNIVERSITY PHINMA");
		txtElem.setBounds(89, 336, 264, 20);
		frame.getContentPane().add(txtElem);
		txtElem.setColumns(10);
		
		txtJHSName = new JTextField();
		txtJHSName.setEnabled(false);
		txtJHSName.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtJHSName.setText("SOUTHWESTERN UNIVERSITY PHINMA");
		txtJHSName.setDisabledTextColor(Color.RED);
		txtJHSName.setBounds(119, 367, 235, 20);
		frame.getContentPane().add(txtJHSName);
		txtJHSName.setColumns(10);
		
		txtName = new JTextField();
		txtName.setEnabled(false);
		txtName.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtName.setDisabledTextColor(Color.RED);
		txtName.setText("SYCLONE JADE GACHO");
		txtName.setBounds(60, 22, 220, 20);
		frame.getContentPane().add(txtName);
		txtName.setColumns(10);
		
		txtAge = new JTextField();
		txtAge.setEnabled(false);
		txtAge.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtAge.setDisabledTextColor(Color.RED);
		txtAge.setText("18");
		txtAge.setColumns(10);
		txtAge.setBounds(60, 53, 220, 20);
		frame.getContentPane().add(txtAge);
		
		txtSex = new JTextField();
		txtSex.setEnabled(false);
		txtSex.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtSex.setDisabledTextColor(Color.RED);
		txtSex.setText("MALE");
		txtSex.setColumns(10);
		txtSex.setBounds(60, 85, 220, 20);
		frame.getContentPane().add(txtSex);
		
		txtAddress = new JTextField();
		txtAddress.setHorizontalAlignment(SwingConstants.LEFT);
		txtAddress.setEnabled(false);
		txtAddress.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtAddress.setDisabledTextColor(Color.RED);
		txtAddress.setBackground(Color.WHITE);
		txtAddress.setText("#24F CASA MIRA TOWERS, GUADALUPE, CEBU CITY");
		txtAddress.setColumns(10);
		txtAddress.setBounds(70, 121, 220, 92);
		frame.getContentPane().add(txtAddress);
		
		txtDoB = new JTextField();
		txtDoB.setEnabled(false);
		txtDoB.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtDoB.setDisabledTextColor(Color.RED);
		txtDoB.setText("AUGUST 27, 2003");
		txtDoB.setColumns(10);
		txtDoB.setBounds(95, 225, 220, 20);
		frame.getContentPane().add(txtDoB);
		
		txtParent = new JTextField();
		txtParent.setEnabled(false);
		txtParent.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtParent.setDisabledTextColor(Color.RED);
		txtParent.setText("RUEL GACHO");
		txtParent.setColumns(10);
		txtParent.setBounds(121, 256, 220, 20);
		frame.getContentPane().add(txtParent);
		
		txtLRN = new JTextField();
		txtLRN.setEnabled(false);
		txtLRN.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtLRN.setDisabledTextColor(Color.RED);
		txtLRN.setText("119882921322");
		txtLRN.setColumns(10);
		txtLRN.setBounds(379, 22, 185, 20);
		frame.getContentPane().add(txtLRN);
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtName.setText(null);
				txtAge.setText(null);
				txtSex.setText(null);
				txtAddress.setText(null);
				txtDoB.setText(null);
				txtParent.setText(null);
				txtLRN.setText(null);
				txtElem.setText(null);
				txtJHSName.setText(null);
				txtElemSY.setText(null);
				txtJHSSY.setText(null);
				
			}
		});
		btnReset.setBounds(45, 461, 89, 23);
		frame.getContentPane().add(btnReset);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				STEMStudents info = new STEMStudents();
				STEMStudents.main(null);
			}
		});
		btnBack.setBounds(303, 461, 89, 23);
		frame.getContentPane().add(btnBack);
		
		
				}
	}

		
		
		
		
	
		

