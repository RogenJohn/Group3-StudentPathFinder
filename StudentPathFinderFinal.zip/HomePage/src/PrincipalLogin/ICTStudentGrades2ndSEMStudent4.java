package PrincipalLogin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.JTextField;
import javax.swing.JButton;

public class ICTStudentGrades2ndSEMStudent4 {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JTextField textField_22;
	private JTextField textField_23;
	private JTextField textField_24;
	private JTextField textField_25;
	private JTextField textField_26;
	private JTextField textField_27;
	private JTextField textField_28;
	private JTextField textField_29;
	private JTextField textField_30;
	private JTextField textField_31;
	private JTextField textField_32;
	private JTextField textField_33;
	private JTextField textField_34;
	private JTextField textField_35;
	private JTextField textField_36;
	private JTextField textField_37;
	private JTextField textField_38;
	private JTextField textField_39;
	private JTextField textField_40;
	private JTextField textField_41;
	private JTextField textField_42;
	private JTextField textField_43;
	private JTextField textField_44;
	private JTextField textField_45;
	private JTextField textField_46;
	private JTextField textField_47;
	private JTextField textField_48;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ICTStudentGrades2ndSEMStudent4 window = new ICTStudentGrades2ndSEMStudent4();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ICTStudentGrades2ndSEMStudent4() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 590, 567);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("COR002 - Reading and Writing");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(10, 132, 242, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("COR004 - Pagbasa at Pagsulat");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(10, 169, 200, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("COR006 - Statistics and Probability");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_3.setBounds(10, 205, 224, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("COR009 - Physical Science");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_4.setBounds(10, 241, 242, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("COR013 - Understanding Culture, Society & Politics");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 8));
		lblNewLabel_5.setBounds(10, 280, 273, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("COR018 - P.E. & Health");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_6.setBounds(10, 313, 180, 14);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("APP001 - Empowerment Technology");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_7.setBounds(10, 348, 242, 14);
		frame.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("APP005 - Practical Research");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_8.setBounds(10, 387, 259, 14);
		frame.getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("APP004 - Entrepreneurship");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_9.setBounds(10, 426, 200, 14);
		frame.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("SSP001 Student Success Program");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_10.setBounds(10, 461, 200, 14);
		frame.getContentPane().add(lblNewLabel_10);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBounds(0, 29, 574, 62);
		panel.setBackground(new Color(139, 0, 0));
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_11 = new JLabel("Subject Description");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_11.setBounds(85, 21, 119, 14);
		panel.add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("1st Grading");
		lblNewLabel_12.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_12.setBounds(257, 11, 65, 35);
		panel.add(lblNewLabel_12);
		
		JLabel lblNewLabel_12_1 = new JLabel("2nd Grading");
		lblNewLabel_12_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_12_1.setBounds(332, 11, 77, 35);
		panel.add(lblNewLabel_12_1);
		
		JLabel lblNewLabel_12_1_1 = new JLabel("Average");
		lblNewLabel_12_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_12_1_1.setBounds(405, 11, 65, 35);
		panel.add(lblNewLabel_12_1_1);
		
		JLabel lblNewLabel_12_1_1_1 = new JLabel("Remarks");
		lblNewLabel_12_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_12_1_1_1.setBounds(462, 11, 65, 35);
		panel.add(lblNewLabel_12_1_1_1);
		
		JLabel lblNewLabel_12_1_1_2 = new JLabel("Units");
		lblNewLabel_12_1_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12_1_1_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_12_1_1_2.setBounds(519, 11, 55, 35);
		panel.add(lblNewLabel_12_1_1_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3.setBounds(73, 0, 2, 60);
		panel.add(panel_3);
		
		JPanel panel_3_1 = new JPanel();
		panel_3_1.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_1.setBounds(245, 0, 2, 60);
		panel.add(panel_3_1);
		
		JPanel panel_3_2 = new JPanel();
		panel_3_2.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_2.setBounds(332, 0, 2, 60);
		panel.add(panel_3_2);
		
		JPanel panel_3_3 = new JPanel();
		panel_3_3.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_3.setBounds(407, 0, 2, 60);
		panel.add(panel_3_3);
		
		JPanel panel_3_4 = new JPanel();
		panel_3_4.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_4.setBounds(462, 0, 2, 60);
		panel.add(panel_3_4);
		
		JPanel panel_3_5 = new JPanel();
		panel_3_5.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_5.setBounds(525, 0, 2, 60);
		panel.add(panel_3_5);
		
		JLabel lblCODENO = new JLabel("Code No.");
		lblCODENO.setBounds(10, 14, 67, 29);
		panel.add(lblCODENO);
		lblCODENO.setFont(new Font("Tahoma", Font.BOLD, 11));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_1.setBounds(0, 85, 574, 36);
		panel_1.setBackground(Color.WHITE);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblSchoolYear = new JLabel("School Year : 2020-2021");
		lblSchoolYear.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblSchoolYear.setBounds(339, 11, 180, 14);
		panel_1.add(lblSchoolYear);
		
		JLabel lblNewLabel = new JLabel("Grade - 11 2nd Semester");
		lblNewLabel.setBounds(21, 11, 180, 14);
		panel_1.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		
		JPanel panel_4_11 = new JPanel();
		panel_4_11.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_4_11.setBackground(Color.BLACK);
		panel_4_11.setBounds(0, 36, 574, 10);
		panel_1.add(panel_4_11);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_2.setBounds(0, 120, 574, 408);
		panel_2.setBackground(Color.WHITE);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JPanel panel_4_9 = new JPanel();
		panel_4_9.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_4_9.setBackground(Color.BLACK);
		panel_4_9.setBounds(0, 362, 574, 10);
		panel_2.add(panel_4_9);
		
		JPanel panel_4_10 = new JPanel();
		panel_4_10.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_4_10.setBackground(Color.BLACK);
		panel_4_10.setBounds(0, 398, 574, 10);
		panel_2.add(panel_4_10);
		
		JPanel panel_4_12 = new JPanel();
		panel_4_12.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12.setBackground(Color.BLACK);
		panel_4_12.setBounds(0, 0, 574, 4);
		panel_2.add(panel_4_12);
		
		JPanel panel_3_1_1 = new JPanel();
		panel_3_1_1.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_1_1.setBounds(244, 0, 2, 372);
		panel_2.add(panel_3_1_1);
		
		JPanel panel_3_1_1_1 = new JPanel();
		panel_3_1_1_1.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_1_1_1.setBounds(332, 0, 2, 330);
		panel_2.add(panel_3_1_1_1);
		
		JPanel panel_3_1_1_2 = new JPanel();
		panel_3_1_1_2.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_1_1_2.setBounds(407, 0, 2, 330);
		panel_2.add(panel_3_1_1_2);
		
		JPanel panel_3_1_1_3 = new JPanel();
		panel_3_1_1_3.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_1_1_3.setBounds(462, 0, 2, 372);
		panel_2.add(panel_3_1_1_3);
		
		JPanel panel_3_1_1_4 = new JPanel();
		panel_3_1_1_4.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_1_1_4.setBounds(528, 0, 2, 372);
		panel_2.add(panel_3_1_1_4);
		
		JLabel lblNewLabel_13 = new JLabel("Total No. of Units Earned");
		lblNewLabel_13.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_13.setBounds(347, 362, 158, 46);
		panel_2.add(lblNewLabel_13);
		
		JPanel panel_3_3_1 = new JPanel();
		panel_3_3_1.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_3_1.setBounds(528, 348, 2, 60);
		panel_2.add(panel_3_3_1);
		
		JPanel panel_4_12_1 = new JPanel();
		panel_4_12_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_1.setBackground(Color.BLACK);
		panel_4_12_1.setBounds(0, 36, 574, 4);
		panel_2.add(panel_4_12_1);
		
		JPanel panel_4_12_2 = new JPanel();
		panel_4_12_2.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_2.setBackground(Color.BLACK);
		panel_4_12_2.setBounds(0, 73, 574, 4);
		panel_2.add(panel_4_12_2);
		
		JPanel panel_4_12_3 = new JPanel();
		panel_4_12_3.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_3.setBackground(Color.BLACK);
		panel_4_12_3.setBounds(0, 110, 574, 4);
		panel_2.add(panel_4_12_3);
		
		JPanel panel_4_12_4 = new JPanel();
		panel_4_12_4.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_4.setBackground(Color.BLACK);
		panel_4_12_4.setBounds(0, 147, 574, 4);
		panel_2.add(panel_4_12_4);
		
		JPanel panel_4_12_5 = new JPanel();
		panel_4_12_5.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_5.setBackground(Color.BLACK);
		panel_4_12_5.setBounds(0, 181, 574, 4);
		panel_2.add(panel_4_12_5);
		
		JPanel panel_4_12_6 = new JPanel();
		panel_4_12_6.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_6.setBackground(Color.BLACK);
		panel_4_12_6.setBounds(0, 216, 574, 4);
		panel_2.add(panel_4_12_6);
		
		JPanel panel_4_12_7 = new JPanel();
		panel_4_12_7.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_7.setBackground(Color.BLACK);
		panel_4_12_7.setBounds(0, 252, 574, 4);
		panel_2.add(panel_4_12_7);
		
		JPanel panel_4_12_8 = new JPanel();
		panel_4_12_8.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_8.setBackground(Color.BLACK);
		panel_4_12_8.setBounds(0, 293, 574, 4);
		panel_2.add(panel_4_12_8);
		
		JPanel panel_4_12_9 = new JPanel();
		panel_4_12_9.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_9.setBackground(Color.BLACK);
		panel_4_12_9.setBounds(0, 330, 574, 4);
		panel_2.add(panel_4_12_9);
		
		textField = new JTextField();
		textField.setDisabledTextColor(Color.BLACK);
		textField.setEnabled(false);
		textField.setText("95");
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField.setColumns(10);
		textField.setBounds(244, 0, 90, 38);
		panel_2.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setDisabledTextColor(Color.BLACK);
		textField_1.setEnabled(false);
		textField_1.setText("90");
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_1.setColumns(10);
		textField_1.setBounds(332, 0, 77, 40);
		panel_2.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setDisabledTextColor(Color.BLACK);
		textField_2.setEnabled(false);
		textField_2.setText("95");
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_2.setColumns(10);
		textField_2.setBounds(244, 39, 90, 38);
		panel_2.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setDisabledTextColor(Color.BLACK);
		textField_3.setEnabled(false);
		textField_3.setText("90");
		textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		textField_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_3.setColumns(10);
		textField_3.setBounds(332, 37, 77, 40);
		panel_2.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setDisabledTextColor(Color.BLACK);
		textField_4.setEnabled(false);
		textField_4.setText("93.5");
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_4.setColumns(10);
		textField_4.setBounds(407, 37, 57, 40);
		panel_2.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setDisabledTextColor(Color.BLACK);
		textField_5.setEnabled(false);
		textField_5.setText("93.5");
		textField_5.setHorizontalAlignment(SwingConstants.CENTER);
		textField_5.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_5.setColumns(10);
		textField_5.setBounds(408, 0, 55, 40);
		panel_2.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setDisabledTextColor(Color.BLACK);
		textField_6.setEnabled(false);
		textField_6.setText("PASSED");
		textField_6.setHorizontalAlignment(SwingConstants.CENTER);
		textField_6.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_6.setColumns(10);
		textField_6.setBounds(462, 0, 67, 40);
		panel_2.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setDisabledTextColor(Color.BLACK);
		textField_7.setEnabled(false);
		textField_7.setText("PASSED");
		textField_7.setHorizontalAlignment(SwingConstants.CENTER);
		textField_7.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_7.setColumns(10);
		textField_7.setBounds(462, 36, 67, 40);
		panel_2.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setDisabledTextColor(Color.BLACK);
		textField_8.setEnabled(false);
		textField_8.setText("4.0");
		textField_8.setHorizontalAlignment(SwingConstants.CENTER);
		textField_8.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_8.setColumns(10);
		textField_8.setBounds(529, 3, 50, 35);
		panel_2.add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setDisabledTextColor(Color.BLACK);
		textField_9.setEnabled(false);
		textField_9.setText("4.0");
		textField_9.setHorizontalAlignment(SwingConstants.CENTER);
		textField_9.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_9.setColumns(10);
		textField_9.setBounds(529, 38, 50, 38);
		panel_2.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setDisabledTextColor(Color.BLACK);
		textField_10.setEnabled(false);
		textField_10.setText("95");
		textField_10.setHorizontalAlignment(SwingConstants.CENTER);
		textField_10.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_10.setColumns(10);
		textField_10.setBounds(244, 73, 90, 38);
		panel_2.add(textField_10);
		
		textField_11 = new JTextField();
		textField_11.setDisabledTextColor(Color.BLACK);
		textField_11.setEnabled(false);
		textField_11.setText("90");
		textField_11.setHorizontalAlignment(SwingConstants.CENTER);
		textField_11.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_11.setColumns(10);
		textField_11.setBounds(332, 74, 77, 40);
		panel_2.add(textField_11);
		
		textField_12 = new JTextField();
		textField_12.setDisabledTextColor(Color.BLACK);
		textField_12.setEnabled(false);
		textField_12.setText("93.5");
		textField_12.setHorizontalAlignment(SwingConstants.CENTER);
		textField_12.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_12.setColumns(10);
		textField_12.setBounds(407, 74, 57, 40);
		panel_2.add(textField_12);
		
		textField_13 = new JTextField();
		textField_13.setDisabledTextColor(Color.BLACK);
		textField_13.setEnabled(false);
		textField_13.setText("PASSED");
		textField_13.setHorizontalAlignment(SwingConstants.CENTER);
		textField_13.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_13.setColumns(10);
		textField_13.setBounds(462, 73, 67, 40);
		panel_2.add(textField_13);
		
		textField_14 = new JTextField();
		textField_14.setDisabledTextColor(Color.BLACK);
		textField_14.setEnabled(false);
		textField_14.setText("4.0");
		textField_14.setHorizontalAlignment(SwingConstants.CENTER);
		textField_14.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_14.setColumns(10);
		textField_14.setBounds(529, 76, 54, 37);
		panel_2.add(textField_14);
		
		textField_15 = new JTextField();
		textField_15.setDisabledTextColor(Color.BLACK);
		textField_15.setEnabled(false);
		textField_15.setText("4.0");
		textField_15.setHorizontalAlignment(SwingConstants.CENTER);
		textField_15.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_15.setColumns(10);
		textField_15.setBounds(529, 112, 51, 38);
		panel_2.add(textField_15);
		
		textField_16 = new JTextField();
		textField_16.setDisabledTextColor(Color.BLACK);
		textField_16.setEnabled(false);
		textField_16.setText("PASSED");
		textField_16.setHorizontalAlignment(SwingConstants.CENTER);
		textField_16.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_16.setColumns(10);
		textField_16.setBounds(463, 110, 67, 40);
		panel_2.add(textField_16);
		
		textField_17 = new JTextField();
		textField_17.setDisabledTextColor(Color.BLACK);
		textField_17.setEnabled(false);
		textField_17.setText("93.5");
		textField_17.setHorizontalAlignment(SwingConstants.CENTER);
		textField_17.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_17.setColumns(10);
		textField_17.setBounds(409, 111, 55, 40);
		panel_2.add(textField_17);
		
		textField_18 = new JTextField();
		textField_18.setDisabledTextColor(Color.BLACK);
		textField_18.setEnabled(false);
		textField_18.setText("90");
		textField_18.setHorizontalAlignment(SwingConstants.CENTER);
		textField_18.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_18.setColumns(10);
		textField_18.setBounds(332, 110, 77, 40);
		panel_2.add(textField_18);
		
		textField_19 = new JTextField();
		textField_19.setDisabledTextColor(Color.BLACK);
		textField_19.setEnabled(false);
		textField_19.setText("95");
		textField_19.setHorizontalAlignment(SwingConstants.CENTER);
		textField_19.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_19.setColumns(10);
		textField_19.setBounds(244, 110, 90, 38);
		panel_2.add(textField_19);
		
		textField_20 = new JTextField();
		textField_20.setDisabledTextColor(Color.BLACK);
		textField_20.setEnabled(false);
		textField_20.setText("95");
		textField_20.setHorizontalAlignment(SwingConstants.CENTER);
		textField_20.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_20.setColumns(10);
		textField_20.setBounds(244, 147, 90, 38);
		panel_2.add(textField_20);
		
		textField_21 = new JTextField();
		textField_21.setDisabledTextColor(Color.BLACK);
		textField_21.setEnabled(false);
		textField_21.setText("95");
		textField_21.setHorizontalAlignment(SwingConstants.CENTER);
		textField_21.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_21.setColumns(10);
		textField_21.setBounds(244, 181, 90, 38);
		panel_2.add(textField_21);
		
		textField_22 = new JTextField();
		textField_22.setDisabledTextColor(Color.BLACK);
		textField_22.setEnabled(false);
		textField_22.setText("95");
		textField_22.setHorizontalAlignment(SwingConstants.CENTER);
		textField_22.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_22.setColumns(10);
		textField_22.setBounds(244, 218, 90, 38);
		panel_2.add(textField_22);
		
		textField_23 = new JTextField();
		textField_23.setDisabledTextColor(Color.BLACK);
		textField_23.setEnabled(false);
		textField_23.setText("95");
		textField_23.setHorizontalAlignment(SwingConstants.CENTER);
		textField_23.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_23.setColumns(10);
		textField_23.setBounds(244, 252, 90, 46);
		panel_2.add(textField_23);
		
		textField_24 = new JTextField();
		textField_24.setDisabledTextColor(Color.BLACK);
		textField_24.setEnabled(false);
		textField_24.setText("95");
		textField_24.setHorizontalAlignment(SwingConstants.CENTER);
		textField_24.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_24.setColumns(10);
		textField_24.setBounds(244, 292, 90, 42);
		panel_2.add(textField_24);
		
		textField_25 = new JTextField();
		textField_25.setDisabledTextColor(Color.BLACK);
		textField_25.setEnabled(false);
		textField_25.setText("90");
		textField_25.setHorizontalAlignment(SwingConstants.CENTER);
		textField_25.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_25.setColumns(10);
		textField_25.setBounds(332, 293, 77, 40);
		panel_2.add(textField_25);
		
		textField_26 = new JTextField();
		textField_26.setDisabledTextColor(Color.BLACK);
		textField_26.setEnabled(false);
		textField_26.setText("90");
		textField_26.setHorizontalAlignment(SwingConstants.CENTER);
		textField_26.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_26.setColumns(10);
		textField_26.setBounds(332, 251, 77, 46);
		panel_2.add(textField_26);
		
		textField_27 = new JTextField();
		textField_27.setDisabledTextColor(Color.BLACK);
		textField_27.setEnabled(false);
		textField_27.setText("90");
		textField_27.setHorizontalAlignment(SwingConstants.CENTER);
		textField_27.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_27.setColumns(10);
		textField_27.setBounds(332, 216, 77, 40);
		panel_2.add(textField_27);
		
		textField_28 = new JTextField();
		textField_28.setDisabledTextColor(Color.BLACK);
		textField_28.setEnabled(false);
		textField_28.setText("90");
		textField_28.setHorizontalAlignment(SwingConstants.CENTER);
		textField_28.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_28.setColumns(10);
		textField_28.setBounds(332, 180, 77, 40);
		panel_2.add(textField_28);
		
		textField_29 = new JTextField();
		textField_29.setDisabledTextColor(Color.BLACK);
		textField_29.setEnabled(false);
		textField_29.setText("90");
		textField_29.setHorizontalAlignment(SwingConstants.CENTER);
		textField_29.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_29.setColumns(10);
		textField_29.setBounds(332, 145, 77, 40);
		panel_2.add(textField_29);
		
		textField_30 = new JTextField();
		textField_30.setDisabledTextColor(Color.BLACK);
		textField_30.setEnabled(false);
		textField_30.setText("93.5");
		textField_30.setHorizontalAlignment(SwingConstants.CENTER);
		textField_30.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_30.setColumns(10);
		textField_30.setBounds(407, 147, 57, 38);
		panel_2.add(textField_30);
		
		textField_31 = new JTextField();
		textField_31.setDisabledTextColor(Color.BLACK);
		textField_31.setEnabled(false);
		textField_31.setText("93.5");
		textField_31.setHorizontalAlignment(SwingConstants.CENTER);
		textField_31.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_31.setColumns(10);
		textField_31.setBounds(409, 181, 55, 40);
		panel_2.add(textField_31);
		
		textField_32 = new JTextField();
		textField_32.setDisabledTextColor(Color.BLACK);
		textField_32.setEnabled(false);
		textField_32.setText("93.5");
		textField_32.setHorizontalAlignment(SwingConstants.CENTER);
		textField_32.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_32.setColumns(10);
		textField_32.setBounds(407, 216, 57, 40);
		panel_2.add(textField_32);
		
		textField_33 = new JTextField();
		textField_33.setDisabledTextColor(Color.BLACK);
		textField_33.setEnabled(false);
		textField_33.setText("93.5");
		textField_33.setHorizontalAlignment(SwingConstants.CENTER);
		textField_33.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_33.setColumns(10);
		textField_33.setBounds(407, 252, 57, 45);
		panel_2.add(textField_33);
		
		textField_34 = new JTextField();
		textField_34.setDisabledTextColor(Color.BLACK);
		textField_34.setEnabled(false);
		textField_34.setText("93.5");
		textField_34.setHorizontalAlignment(SwingConstants.CENTER);
		textField_34.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_34.setColumns(10);
		textField_34.setBounds(407, 293, 57, 38);
		panel_2.add(textField_34);
		
		textField_35 = new JTextField();
		textField_35.setDisabledTextColor(Color.BLACK);
		textField_35.setEnabled(false);
		textField_35.setText("PASSED");
		textField_35.setHorizontalAlignment(SwingConstants.CENTER);
		textField_35.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_35.setColumns(10);
		textField_35.setBounds(464, 293, 67, 39);
		panel_2.add(textField_35);
		
		textField_36 = new JTextField();
		textField_36.setDisabledTextColor(Color.BLACK);
		textField_36.setEnabled(false);
		textField_36.setText("PASSED");
		textField_36.setHorizontalAlignment(SwingConstants.CENTER);
		textField_36.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_36.setColumns(10);
		textField_36.setBounds(463, 253, 67, 45);
		panel_2.add(textField_36);
		
		textField_37 = new JTextField();
		textField_37.setDisabledTextColor(Color.BLACK);
		textField_37.setEnabled(false);
		textField_37.setText("PASSED");
		textField_37.setHorizontalAlignment(SwingConstants.CENTER);
		textField_37.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_37.setColumns(10);
		textField_37.setBounds(463, 216, 67, 40);
		panel_2.add(textField_37);
		
		textField_38 = new JTextField();
		textField_38.setDisabledTextColor(Color.BLACK);
		textField_38.setEnabled(false);
		textField_38.setText("PASSED");
		textField_38.setHorizontalAlignment(SwingConstants.CENTER);
		textField_38.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_38.setColumns(10);
		textField_38.setBounds(462, 181, 67, 40);
		panel_2.add(textField_38);
		
		textField_39 = new JTextField();
		textField_39.setDisabledTextColor(Color.BLACK);
		textField_39.setEnabled(false);
		textField_39.setText("PASSED");
		textField_39.setHorizontalAlignment(SwingConstants.CENTER);
		textField_39.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_39.setColumns(10);
		textField_39.setBounds(463, 144, 67, 40);
		panel_2.add(textField_39);
		
		textField_40 = new JTextField();
		textField_40.setDisabledTextColor(Color.BLACK);
		textField_40.setEnabled(false);
		textField_40.setText("4.0");
		textField_40.setHorizontalAlignment(SwingConstants.CENTER);
		textField_40.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_40.setColumns(10);
		textField_40.setBounds(528, 146, 50, 38);
		panel_2.add(textField_40);
		
		textField_41 = new JTextField();
		textField_41.setDisabledTextColor(Color.BLACK);
		textField_41.setEnabled(false);
		textField_41.setText("4.0");
		textField_41.setHorizontalAlignment(SwingConstants.CENTER);
		textField_41.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_41.setColumns(10);
		textField_41.setBounds(528, 183, 52, 35);
		panel_2.add(textField_41);
		
		textField_42 = new JTextField();
		textField_42.setDisabledTextColor(Color.BLACK);
		textField_42.setEnabled(false);
		textField_42.setText("4.0");
		textField_42.setHorizontalAlignment(SwingConstants.CENTER);
		textField_42.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_42.setColumns(10);
		textField_42.setBounds(529, 218, 52, 35);
		panel_2.add(textField_42);
		
		textField_43 = new JTextField();
		textField_43.setDisabledTextColor(Color.BLACK);
		textField_43.setEnabled(false);
		textField_43.setText("4.0");
		textField_43.setHorizontalAlignment(SwingConstants.CENTER);
		textField_43.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_43.setColumns(10);
		textField_43.setBounds(529, 255, 50, 42);
		panel_2.add(textField_43);
		
		textField_44 = new JTextField();
		textField_44.setDisabledTextColor(Color.BLACK);
		textField_44.setEnabled(false);
		textField_44.setText("4.0");
		textField_44.setHorizontalAlignment(SwingConstants.CENTER);
		textField_44.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_44.setColumns(10);
		textField_44.setBounds(529, 297, 51, 35);
		panel_2.add(textField_44);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4.setBounds(0, 0, 574, 1);
		frame.getContentPane().add(panel_4);
		
		JButton btnBackTost = new JButton("Back to 1st SEM");
		btnBackTost.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnBackTost.setBackground(Color.LIGHT_GRAY);
		btnBackTost.setBounds(406, 0, 168, 30);
		frame.getContentPane().add(btnBackTost);
		btnBackTost.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ICTStudentGrades1Student4 info = new ICTStudentGrades1Student4();
				ICTStudentGrades1Student4.main(null);
			}
		});
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ICTStudents info = new ICTStudents();
				ICTStudents.main(null);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setBounds(10, 374, 67, 23);
		panel_2.add(btnNewButton);
		
		textField_45 = new JTextField();
		textField_45.setText("COMPLETED");
		textField_45.setHorizontalAlignment(SwingConstants.CENTER);
		textField_45.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_45.setColumns(10);
		textField_45.setBounds(244, 331, 220, 35);
		panel_2.add(textField_45);
		
		textField_46 = new JTextField();
		textField_46.setText("PASSED");
		textField_46.setHorizontalAlignment(SwingConstants.CENTER);
		textField_46.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_46.setEnabled(false);
		textField_46.setDisabledTextColor(Color.BLACK);
		textField_46.setColumns(10);
		textField_46.setBounds(463, 330, 67, 35);
		panel_2.add(textField_46);
		
		textField_47 = new JTextField();
		textField_47.setText("3.0");
		textField_47.setHorizontalAlignment(SwingConstants.CENTER);
		textField_47.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_47.setEnabled(false);
		textField_47.setDisabledTextColor(Color.BLACK);
		textField_47.setColumns(10);
		textField_47.setBounds(528, 330, 46, 35);
		panel_2.add(textField_47);
		
		textField_48 = new JTextField();
		textField_48.setText("36.0");
		textField_48.setHorizontalAlignment(SwingConstants.CENTER);
		textField_48.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_48.setEnabled(false);
		textField_48.setDisabledTextColor(Color.BLACK);
		textField_48.setColumns(10);
		textField_48.setBounds(528, 370, 46, 38);
		panel_2.add(textField_48);
		
		JLabel lblNewLabel_14 = new JLabel("CARTILLA, KISHEY");
		lblNewLabel_14.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_14.setBounds(10, 0, 156, 30);
		frame.getContentPane().add(lblNewLabel_14);
	}
}
