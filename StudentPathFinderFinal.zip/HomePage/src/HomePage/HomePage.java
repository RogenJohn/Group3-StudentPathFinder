package HomePage;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JTextField;

import PrincipalLogin.PrincipalLogin;
import SecretaryLogin.SecretaryLogin;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class HomePage {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomePage window = new HomePage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public HomePage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setForeground(Color.WHITE);
		frame.setBounds(100, 100, 590, 567);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnPrincipal = new JButton("PRINCIPAL");
		btnPrincipal.setForeground(Color.BLACK);
		btnPrincipal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PrincipalLogin info = new PrincipalLogin();
				PrincipalLogin.main(null);
			}
		});
		btnPrincipal.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnPrincipal.setBackground(Color.LIGHT_GRAY);
		btnPrincipal.setBounds(392, 473, 116, 39);
		frame.getContentPane().add(btnPrincipal);
		
		JButton btnSecretary = new JButton("SECRETARY");
		btnSecretary.setForeground(Color.BLACK);
		btnSecretary.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SecretaryLogin info = new SecretaryLogin();
				SecretaryLogin.main(null);
			}
		});
		btnSecretary.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSecretary.setBackground(Color.LIGHT_GRAY);
		btnSecretary.setBounds(66, 473, 116, 39);
		frame.getContentPane().add(btnSecretary);
		
		JLabel lblTitle = new JLabel("STUDENT PATHFINDER");
		lblTitle.setBounds(66, 11, 442, 74);
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 38));
		frame.getContentPane().add(lblTitle);
		
		JLabel lblTitle2 = new JLabel("COLLEGE OF INFORMATION TECHNOLOGY AND ENGINEERING");
		lblTitle2.setBounds(51, 77, 467, 39);
		lblTitle2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().add(lblTitle2);
		
		JLabel lblLOGO = new JLabel("");
		lblLOGO.setBounds(76, 96, 400, 392);
		lblLOGO.setIcon(new ImageIcon(HomePage.class.getResource("/res/LOGO2.png")));
		frame.getContentPane().add(lblLOGO);
	}
}
