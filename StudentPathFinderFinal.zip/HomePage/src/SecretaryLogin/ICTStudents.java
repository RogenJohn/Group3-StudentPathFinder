package SecretaryLogin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JTextPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.UIManager;



import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class ICTStudents {

	private JFrame frame;
	private JTextField txtField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ICTStudents window = new ICTStudents();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ICTStudents() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setEnabled(false);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSTEMStudents = new JLabel("LIST OF ICT STUDENTS");
		lblSTEMStudents.setFont(new Font("Tahoma", Font.BOLD, 34));
		lblSTEMStudents.setBounds(74, 79, 432, 35);
		frame.getContentPane().add(lblSTEMStudents);
		
		JTextPane ICTStudent1 = new JTextPane();
		ICTStudent1.setFont(new Font("Tahoma", Font.BOLD, 14));
		ICTStudent1.setBackground(Color.LIGHT_GRAY);
		ICTStudent1.setText("ARNAN, JOHN LOUIS");
		ICTStudent1.setBounds(50, 149, 235, 23);
		frame.getContentPane().add(ICTStudent1);
		
		JTextPane ICTStudent2 = new JTextPane();
		ICTStudent2.setFont(new Font("Tahoma", Font.BOLD, 14));
		ICTStudent2.setText("BUENO, JAKE LAURENCE");
		ICTStudent2.setBackground(Color.LIGHT_GRAY);
		ICTStudent2.setBounds(50, 206, 235, 23);
		frame.getContentPane().add(ICTStudent2);
		
		JButton btnSTEMStudent2INFO = new JButton("INFO");
		btnSTEMStudent2INFO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentRecord7 info = new StudentRecord7();
				StudentRecord7.main(null);
			}
		});
		btnSTEMStudent2INFO.setForeground(Color.RED);
		btnSTEMStudent2INFO.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent2INFO.setBounds(290, 206, 89, 23);
		frame.getContentPane().add(btnSTEMStudent2INFO);
		
		JButton btnSTEMStudent2GRADES = new JButton("GRADES");
		btnSTEMStudent2GRADES.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ICTStudentGrades1Student2 info = new ICTStudentGrades1Student2();
				ICTStudentGrades1Student2.main(null);
			}
		});
		btnSTEMStudent2GRADES.setForeground(Color.RED);
		btnSTEMStudent2GRADES.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent2GRADES.setBounds(389, 206, 117, 23);
		frame.getContentPane().add(btnSTEMStudent2GRADES);
		
		JTextPane ICTStudent3 = new JTextPane();
		ICTStudent3.setText("FALCONE, JULIAN FLORENZ");
		ICTStudent3.setFont(new Font("Tahoma", Font.BOLD, 14));
		ICTStudent3.setBackground(Color.LIGHT_GRAY);
		ICTStudent3.setBounds(50, 263, 235, 23);
		frame.getContentPane().add(ICTStudent3);
		
		JButton btnSTEMStudent3INFO = new JButton("INFO");
		btnSTEMStudent3INFO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentRecord8 info = new StudentRecord8();
				StudentRecord8.main(null);
			}
		});
		btnSTEMStudent3INFO.setForeground(Color.RED);
		btnSTEMStudent3INFO.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent3INFO.setBounds(290, 263, 89, 23);
		frame.getContentPane().add(btnSTEMStudent3INFO);
		
		JButton btnSTEMStudent3GRADES = new JButton("GRADES");
		btnSTEMStudent3GRADES.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ICTStudentGrades1Student3 info = new ICTStudentGrades1Student3();
				ICTStudentGrades1Student3.main(null);
			}
		});
		btnSTEMStudent3GRADES.setForeground(Color.RED);
		btnSTEMStudent3GRADES.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent3GRADES.setBounds(389, 263, 117, 23);
		frame.getContentPane().add(btnSTEMStudent3GRADES);
		
		JTextPane ICTStudent4 = new JTextPane();
		ICTStudent4.setText("CARTILLA, KISHEY");
		ICTStudent4.setFont(new Font("Tahoma", Font.BOLD, 14));
		ICTStudent4.setBackground(Color.LIGHT_GRAY);
		ICTStudent4.setBounds(50, 318, 235, 23);
		frame.getContentPane().add(ICTStudent4);
		
		JButton btnSTEMStudent4INFO = new JButton("INFO");
		btnSTEMStudent4INFO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentRecord9 info = new StudentRecord9();
				StudentRecord9.main(null);
			}
		});
		btnSTEMStudent4INFO.setForeground(Color.RED);
		btnSTEMStudent4INFO.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent4INFO.setBounds(290, 318, 89, 23);
		frame.getContentPane().add(btnSTEMStudent4INFO);
		
		JButton btnSTEMStudent4GRADES = new JButton("GRADES");
		btnSTEMStudent4GRADES.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ICTStudentGrades1Student4 info = new ICTStudentGrades1Student4();
				ICTStudentGrades1Student4.main(null);
			}
		});
		btnSTEMStudent4GRADES.setForeground(Color.RED);
		btnSTEMStudent4GRADES.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent4GRADES.setBounds(389, 318, 117, 23);
		frame.getContentPane().add(btnSTEMStudent4GRADES);
		
		JTextPane ICTStudent5 = new JTextPane();
		ICTStudent5.setText("LABITAD, NICHOLE");
		ICTStudent5.setFont(new Font("Tahoma", Font.BOLD, 14));
		ICTStudent5.setBackground(Color.LIGHT_GRAY);
		ICTStudent5.setBounds(50, 375, 235, 23);
		frame.getContentPane().add(ICTStudent5);
		
		JButton btnSTEMStudent5INFO = new JButton("INFO");
		btnSTEMStudent5INFO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentRecord10 info = new StudentRecord10();
				StudentRecord10.main(null);
			}
		});
		btnSTEMStudent5INFO.setForeground(Color.RED);
		btnSTEMStudent5INFO.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent5INFO.setBounds(290, 375, 89, 23);
		frame.getContentPane().add(btnSTEMStudent5INFO);
		
		JButton btnSTEMStudent5GRADES = new JButton("GRADES");
		btnSTEMStudent5GRADES.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ICTStudentGrades1Student5 info = new ICTStudentGrades1Student5();
				ICTStudentGrades1Student5.main(null);
			}
		});
		btnSTEMStudent5GRADES.setForeground(Color.RED);
		btnSTEMStudent5GRADES.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent5GRADES.setBounds(389, 375, 117, 23);
		frame.getContentPane().add(btnSTEMStudent5GRADES);
		
		JButton btnSTEMStudent1INFO = new JButton("INFO");
		btnSTEMStudent1INFO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentRecord6 info = new StudentRecord6();
				StudentRecord6.main(null);
			}
		});
		btnSTEMStudent1INFO.setForeground(Color.RED);
		btnSTEMStudent1INFO.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent1INFO.setBounds(290, 149, 89, 23);
		frame.getContentPane().add(btnSTEMStudent1INFO);
		
		JButton btnSTEMStudent1GRADES = new JButton("GRADES");
		btnSTEMStudent1GRADES.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ICTStudentGrades1Student1 info = new ICTStudentGrades1Student1();
				ICTStudentGrades1Student1.main(null);
			}
		});
		btnSTEMStudent1GRADES.setForeground(Color.RED);
		btnSTEMStudent1GRADES.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSTEMStudent1GRADES.setBounds(389, 149, 117, 23);
		frame.getContentPane().add(btnSTEMStudent1GRADES);
		
		frame.setBounds(100, 100, 590, 567);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentPathFinder info = new StudentPathFinder();
				StudentPathFinder.main(null);
			}});
		btnBack.setBounds(50, 459, 89, 23);
		frame.getContentPane().add(btnBack);
		frame.setBounds(100, 100, 590, 567);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
