package SecretaryLogin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

public class StudentGrades1 {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentGrades1 window = new StudentGrades1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudentGrades1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 590, 567);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("COR001 - Oral Communication in Context");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(10, 132, 242, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("COR003 - Filipino (Pananaliksik)");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(10, 169, 200, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("COR005 - General Mathematics");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_3.setBounds(10, 205, 200, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("COR008 - Earth Science");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_4.setBounds(10, 241, 200, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("COR011 - 21st Century Literature");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_5.setBounds(10, 280, 200, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("COR015 - Philosophy");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_6.setBounds(10, 313, 180, 14);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("COR017 - P.E. & Health");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_7.setBounds(10, 348, 180, 14);
		frame.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("APP002 - English Academic & Professional");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_8.setBounds(10, 387, 259, 14);
		frame.getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("STEM001 - Pre Calculus");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_9.setBounds(10, 426, 200, 14);
		frame.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("SSP001 Student Success Program");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_10.setBounds(10, 461, 200, 14);
		frame.getContentPane().add(lblNewLabel_10);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBounds(0, 31, 574, 60);
		panel.setBackground(new Color(139, 0, 0));
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_11 = new JLabel("Subject Description");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_11.setBounds(85, 21, 119, 14);
		panel.add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("1st Grading");
		lblNewLabel_12.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_12.setBounds(257, 11, 65, 35);
		panel.add(lblNewLabel_12);
		
		JLabel lblNewLabel_12_1 = new JLabel("2nd Grading");
		lblNewLabel_12_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_12_1.setBounds(332, 11, 77, 35);
		panel.add(lblNewLabel_12_1);
		
		JLabel lblNewLabel_12_1_1 = new JLabel("Average");
		lblNewLabel_12_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_12_1_1.setBounds(405, 11, 65, 35);
		panel.add(lblNewLabel_12_1_1);
		
		JLabel lblNewLabel_12_1_1_1 = new JLabel("Remarks");
		lblNewLabel_12_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_12_1_1_1.setBounds(462, 11, 65, 35);
		panel.add(lblNewLabel_12_1_1_1);
		
		JLabel lblNewLabel_12_1_1_2 = new JLabel("Units");
		lblNewLabel_12_1_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12_1_1_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_12_1_1_2.setBounds(519, 11, 55, 35);
		panel.add(lblNewLabel_12_1_1_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3.setBounds(73, 0, 2, 60);
		panel.add(panel_3);
		
		JPanel panel_3_1 = new JPanel();
		panel_3_1.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_1.setBounds(245, 0, 2, 60);
		panel.add(panel_3_1);
		
		JPanel panel_3_2 = new JPanel();
		panel_3_2.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_2.setBounds(332, 0, 2, 60);
		panel.add(panel_3_2);
		
		JPanel panel_3_3 = new JPanel();
		panel_3_3.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_3.setBounds(407, 0, 2, 60);
		panel.add(panel_3_3);
		
		JPanel panel_3_4 = new JPanel();
		panel_3_4.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_4.setBounds(462, 0, 2, 60);
		panel.add(panel_3_4);
		
		JPanel panel_3_5 = new JPanel();
		panel_3_5.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_5.setBounds(525, 0, 2, 60);
		panel.add(panel_3_5);
		
		JLabel lblCODENO = new JLabel("Code No.");
		lblCODENO.setBounds(10, 14, 67, 29);
		panel.add(lblCODENO);
		lblCODENO.setFont(new Font("Tahoma", Font.BOLD, 11));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_1.setBounds(0, 85, 574, 36);
		panel_1.setBackground(Color.WHITE);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblSchoolYear = new JLabel("School Year : 2020-2021");
		lblSchoolYear.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblSchoolYear.setBounds(339, 11, 180, 14);
		panel_1.add(lblSchoolYear);
		
		JLabel lblNewLabel = new JLabel("Grade - 11 1st Semester");
		lblNewLabel.setBounds(21, 11, 180, 14);
		panel_1.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		
		JPanel panel_4_11 = new JPanel();
		panel_4_11.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_4_11.setBackground(Color.BLACK);
		panel_4_11.setBounds(0, 36, 574, 10);
		panel_1.add(panel_4_11);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_2.setBounds(0, 120, 574, 408);
		panel_2.setBackground(Color.WHITE);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JPanel panel_4_9 = new JPanel();
		panel_4_9.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_4_9.setBackground(Color.BLACK);
		panel_4_9.setBounds(0, 362, 574, 10);
		panel_2.add(panel_4_9);
		
		JPanel panel_4_10 = new JPanel();
		panel_4_10.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_4_10.setBackground(Color.BLACK);
		panel_4_10.setBounds(0, 398, 574, 10);
		panel_2.add(panel_4_10);
		
		JPanel panel_4_12 = new JPanel();
		panel_4_12.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12.setBackground(Color.BLACK);
		panel_4_12.setBounds(0, 0, 574, 4);
		panel_2.add(panel_4_12);
		
		JPanel panel_3_1_1 = new JPanel();
		panel_3_1_1.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_1_1.setBounds(244, 0, 2, 372);
		panel_2.add(panel_3_1_1);
		
		JPanel panel_3_1_1_1 = new JPanel();
		panel_3_1_1_1.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_1_1_1.setBounds(332, 0, 2, 330);
		panel_2.add(panel_3_1_1_1);
		
		JPanel panel_3_1_1_2 = new JPanel();
		panel_3_1_1_2.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_1_1_2.setBounds(407, 0, 2, 330);
		panel_2.add(panel_3_1_1_2);
		
		JPanel panel_3_1_1_3 = new JPanel();
		panel_3_1_1_3.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_1_1_3.setBounds(462, 0, 2, 372);
		panel_2.add(panel_3_1_1_3);
		
		JPanel panel_3_1_1_4 = new JPanel();
		panel_3_1_1_4.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_1_1_4.setBounds(528, 0, 2, 372);
		panel_2.add(panel_3_1_1_4);
		
		JLabel lblNewLabel_13 = new JLabel("Total No. of Units Earned");
		lblNewLabel_13.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_13.setBounds(347, 362, 158, 46);
		panel_2.add(lblNewLabel_13);
		
		JPanel panel_3_3_1 = new JPanel();
		panel_3_3_1.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3_3_1.setBounds(528, 348, 2, 60);
		panel_2.add(panel_3_3_1);
		
		JPanel panel_4_12_1 = new JPanel();
		panel_4_12_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_1.setBackground(Color.BLACK);
		panel_4_12_1.setBounds(0, 36, 574, 4);
		panel_2.add(panel_4_12_1);
		
		JPanel panel_4_12_2 = new JPanel();
		panel_4_12_2.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_2.setBackground(Color.BLACK);
		panel_4_12_2.setBounds(0, 73, 574, 4);
		panel_2.add(panel_4_12_2);
		
		JPanel panel_4_12_3 = new JPanel();
		panel_4_12_3.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_3.setBackground(Color.BLACK);
		panel_4_12_3.setBounds(0, 110, 574, 4);
		panel_2.add(panel_4_12_3);
		
		JPanel panel_4_12_4 = new JPanel();
		panel_4_12_4.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_4.setBackground(Color.BLACK);
		panel_4_12_4.setBounds(0, 147, 574, 4);
		panel_2.add(panel_4_12_4);
		
		JPanel panel_4_12_5 = new JPanel();
		panel_4_12_5.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_5.setBackground(Color.BLACK);
		panel_4_12_5.setBounds(0, 181, 574, 4);
		panel_2.add(panel_4_12_5);
		
		JPanel panel_4_12_6 = new JPanel();
		panel_4_12_6.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_6.setBackground(Color.BLACK);
		panel_4_12_6.setBounds(0, 216, 574, 4);
		panel_2.add(panel_4_12_6);
		
		JPanel panel_4_12_7 = new JPanel();
		panel_4_12_7.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_7.setBackground(Color.BLACK);
		panel_4_12_7.setBounds(0, 252, 574, 4);
		panel_2.add(panel_4_12_7);
		
		JPanel panel_4_12_8 = new JPanel();
		panel_4_12_8.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_8.setBackground(Color.BLACK);
		panel_4_12_8.setBounds(0, 293, 574, 4);
		panel_2.add(panel_4_12_8);
		
		JPanel panel_4_12_9 = new JPanel();
		panel_4_12_9.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4_12_9.setBackground(Color.BLACK);
		panel_4_12_9.setBounds(0, 330, 574, 4);
		panel_2.add(panel_4_12_9);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4.setBounds(0, 0, 574, 1);
		frame.getContentPane().add(panel_4);
	}
}
